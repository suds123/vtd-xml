/* 
 * Copyright (C) 2002-2012 XimpleWare, info@ximpleware.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#ifndef VTDGEN_H
#define VTDGEN_H

//#include "customTypes.h"
#include "fastLongBuffer.h"
#include "fastIntBuffer.h"
#include "vtdNav.h"
#include "UTF8Char.h"
#include "XMLChar.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


// define document encoding

// other constants

#define ATTR_NAME_ARRAY_SIZE 16
#define TAG_STACK_SIZE 256
#define MAX_DEPTH 254
#define MAX_TOKEN_LENGTH ((1<<20)-1)
#define MAX_PREFIX_LENGTH ((1<<9)-1)
#define MAX_QNAME_LENGTH ((1<<11)-1)

typedef struct vTDGen {
	int ns;
	int VTDDepth;
	encoding_t encoding;
	int last_depth;
	int last_l1_index;
	int last_l2_index;
	int last_i3_index;

	int increment;
	Boolean BOM_detected;
	Boolean must_utf_8;
	int ch;
	int ch_temp;
	int offset;
	int temp_offset;
	int depth;

	int prev_offset;
	int rootIndex;
	UByte* XMLDoc; // byte buffer containing
	int docLen; // length of XML (can be a segment of XMLDoc)
	int bufLen; // length of XMLDoc (possibly bigger than docLen)

	// buffers
	FastLongBuffer *VTDBuffer;
	FastLongBuffer *l1Buffer;
	FastLongBuffer *l2Buffer;
	FastIntBuffer *l3Buffer;

	Boolean br;//buffer reuse flag
	Boolean stateTransfered; // indicate whether VTDNav has received all LC and VTD buffers

	int endOffset;
	Long* tag_stack;
	Long* attr_name_array;
	int anaLen;
	int docOffset;
} VTDGen;

// create VTDGen
VTDGen *createVTDGen();

// free VTDGen
void freeVTDGen(VTDGen *vg);

// clear the internal state of VTDGen so it can process 
// the next XML file
void clear(VTDGen *vg);

// Returns the VTDNav object after parsing, it also cleans 
// internal state so VTDGen can process the next file.
VTDNav *getNav(VTDGen *vg);

// Generating VTD tokens and Location cache info.
// One specifies whether the parsing is namespace aware or not.
void parse(VTDGen *vg, Boolean ns);

Boolean parseFile(VTDGen *vg, Boolean ns,char *fileName);

// Set the XMLDoc container.
void setDoc(VTDGen *vg, UByte *byteArray, int arrayLen);

// Set the XMLDoc container.Also set the offset and len of the document 
void setDoc2(VTDGen *vg, UByte *byteArray, int arrayLen, int offset, int docLen);

// set the XML Doc container and turn on buffer reuse
void setDoc_BR(VTDGen *vg, UByte *byteArray, int arrayLen);

//Set the XMLDoc container.Also set the offset and len of the document 
void setDoc_BR2(VTDGen *vg, UByte *byteArray, int arrayLen, int offset, int docLen);

/* definition for struct intHash*/
#define ih_mask1 0x7ff
#define ih_mask2 0xfffff800
#define ih_hashWidth 2048
#define ih_hashWidthE 11
#define ih_pageSizeE 5
typedef struct intHash {
   struct fastIntBuffer **storage;	
   int m1;  /* mask1 */
   int m2;  /* mask2 */
   int pse; /* page size exponential */
   int hw;  
   int maxDepth;
} IntHash;

/* function for intHash
 see intHash.c for implemenation*/
IntHash* createIntHash();
IntHash* createIntHash2(int hashWidthExpo);
int determineHashWidth(int i);
void freeIntHash(IntHash *ih);
Boolean isUniqueIntHash(IntHash *ih,int i);
void resetIntHash(IntHash *ih);
#endif
