/* 
 * Copyright (C) 2002-2012 XimpleWare, info@ximpleware.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
#include "autoPilot.h"

/*create AutoPilot throw exception if allocation failed*/
AutoPilot *createAutoPilot(VTDNav *v){
	AutoPilot *ap = NULL;
	if (v == NULL){
		throwException2(invalid_argument,
			" createAutoPilot failed: can't take NULL VTDNav pointer");
		return NULL;
	}

	ap = (AutoPilot *)malloc(sizeof(AutoPilot));
	if (ap == NULL){
		throwException2(out_of_mem,
			"createAutoPilot failed");
		return NULL;
	}
    ap->elementName = NULL;
	ap->localName = NULL;
	ap->URL = NULL;
    ap->vn = v;
    ap->it = UNDEFINED; /* initial state: not defined */
    ap->ft = TRUE;
	//ap->startIndex = -1;
	//ap->xpe = NULL;
	ap->nl = NULL;
	ap->contextCopy = NULL;
	ap->special = FALSE;
	return ap;
}

/* a argument-less constructor for autoPilot, 
   out_of_mem exception if allocation failed  */
AutoPilot *createAutoPilot2(){
	AutoPilot *ap = NULL;
	ap = (AutoPilot *)malloc(sizeof(AutoPilot));
	if (ap == NULL){
		throwException2(out_of_mem,
			"createAutoPilot failed");
		return NULL;
	}
    ap->elementName = NULL;
	ap->localName = NULL;
	ap->URL = NULL;
    ap->vn = NULL;
    //depth = v.getCurrentDepth();
    ap->it = UNDEFINED; // not defined
    ap->ft = TRUE;
	//ap->xpe = NULL;
	//ap->startIndex = -1;
	ap->nl = NULL;
	ap->contextCopy = NULL;
	ap->special = FALSE;
	return ap;
}

/* free AutoPilot */
void freeAutoPilot(AutoPilot *ap){
	
	if (ap!=NULL){
		if (ap->contextCopy!=NULL)
			free(ap->contextCopy);
		//if (ap->xpe!= NULL)
		//ap->xpe->freeExpr(ap->xpe);
	}	
	free(ap);

}



/*Select the element name before iterating*/
void selectElement(AutoPilot *ap, UCSChar *en){
    if (en == NULL){
		 throwException2( invalid_argument,
			 " invalid argument for selectElement, elementName can't be NULL");
	 }
    ap->it = SIMPLE;
    ap->depth = getCurrentDepth(ap->vn);
    ap->elementName = en;
    ap->ft = TRUE;
}

/*Select the element name (name space version) before iterating.
// * URL, if set to *, matches every namespace
// * URL, if set to null, indicates the namespace is undefined.
// * localname, if set to *, matches any localname */
void selectElementNS(AutoPilot *ap, UCSChar *URL, UCSChar *ln){
    if (ln == NULL){
		 throwException2( invalid_argument,
			 " invalid argument for selectElementNS, localName can't be NULL");
	}
    ap->it = SIMPLE_NS;
    ap->depth = getCurrentDepth(ap->vn);
    ap->localName = ln;
	ap->URL = URL;
    ap->ft = TRUE;
}



/*Iterate over all the selected element nodes in document order.*/
Boolean iterateAP(AutoPilot *ap){
	switch (ap->it) {
		case SIMPLE :
			if (ap->vn->atTerminal)
				return FALSE;
			if (ap->ft == FALSE)
				return iterate(ap->vn, ap->depth, ap->elementName, ap->special);
			else {
				ap->ft = FALSE;
				if (ap->special || matchElement(ap->vn, ap->elementName)) {
					return TRUE;
				} else
					return iterate(ap->vn, ap->depth, ap->elementName,ap->special);
			}
		case SIMPLE_NS :
			if (ap->vn->atTerminal)
				return FALSE;
			if (ap->ft == FALSE)
				return iterateNS(ap->vn, ap->depth, ap->URL, ap->localName);
			else {
				ap->ft = FALSE;
				if (matchElementNS(ap->vn, ap->URL, ap->localName)) {
					
					return TRUE;
				} else
					return iterateNS(ap->vn, ap->depth, ap->URL, ap->localName);
			}

		default :
			throwException2(pilot_exception,
				"unknow iteration type for iterateAP");
			return FALSE;
	}
}

/*
 * This function selects the string representing XPath expression
 * Usually evalXPath is called afterwards
 */

/**
 * 
 */
void bind(AutoPilot *ap, VTDNav *new_vn){
	ap->elementName = NULL;
    ap->vn = new_vn;
	ap->it = UNDEFINED; 
    ap->ft = TRUE;
    ap->size = 0;
    ap->special = FALSE;
}

