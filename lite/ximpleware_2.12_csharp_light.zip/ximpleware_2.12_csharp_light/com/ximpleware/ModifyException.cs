using System;
using System.Collections.Generic;
using System.Text;

namespace com.ximpleware
{
    public class ModifyException : System.Exception
    {
        		/// <summary> ModifyException constructor comment.</summary>
		public ModifyException():base()
		{
		}
		/// <summary> ModifyException constructor comment.</summary>
		/// <param name="s">java.lang.String
		/// </param>
		public ModifyException(System.String s):base(s)
		{
		}
    }
}
