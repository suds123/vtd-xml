README 

  This is the C# release of VTD-XML version 2.12 light. It contains the parsing ,navigation and modification functions of the standard version. 

Files Included in this directory
  README: this file.
  
  Full GPL license is in "License.txt."

  "com\ximpleware\"  and "com\ximpleware\parser\" 
contain the source code.

  ".\bin" contains the release and debug build of dll library file.


  Some examples are under "/examples."

  Also you can read all the documents online at "http://vtd-xml.sf.net."

  Let us know what you think and help us improve the software. Please email us: 
info@ximpleware.com. 
