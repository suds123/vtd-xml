﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace com.ximpleware
{
   public class CachedExpr: Expr {
	Expr e;
	bool cached;
	bool eb;
	double en;
	String es;
	FastIntBuffer ens;
	int count;
	VTDNav vn1;

	public CachedExpr(Expr e1){
		e=e1;
		cached = false;
		ens=null;
		count=0;
		vn1=null;
	}
	
	public override bool evalBoolean(VTDNav vn) {
		// TODO Auto-generated method stub
		if (cached){
			return eb;
		}else{
			eb = e.evalBoolean(vn);
			return eb;
		}
	}


	public override double evalNumber(VTDNav vn) {
		// TODO Auto-generated method stub
		if (cached){
			return en;
		}else{
			cached = true;
			en = e.evalNumber(vn);
			return en;
		}
	}

	public override int evalNodeSet(VTDNav vn) {
		// TODO Auto-generated method stub
		int i=-1;
		if (cached){
			if (count<ens.size){
				i=ens.intAt(count);
				vn.recoverNode(i);
				count++;
				return i;
			}else
				return -1;

		}else{
			cached = true;
			
			if (ens==null){
				ens = new FastIntBuffer(8);//page size 64
			}
			//record node set
			while((i=e.evalNodeSet(vn))!=-1){
				ens.append(i);
			}
			e.reset(vn);
			if(ens.size>0){
				i=ens.intAt(count);//count should be zero
				vn.recoverNode(i);
				count++;
				return i;
			}else
				return -1;
		}
	}

	
	public override String evalString(VTDNav vn) {
		if (cached){
			return es;
		}else{
			cached = true;
			es = e.evalString(vn);
			return es;
		}		
	}

	
	public void reset(VTDNav vn) {
		count=0;
		/*if (vn1!=vn){
			cached = false;
			if (ens!=null)
				ens.clear();
			e.reset(vn);
		}*/
		// TODO Auto-generated method stub
	}

	public override String toString() {
		// TODO Auto-generated method stub
		return "cached("+e.toString()+")";
	}

	public override bool isNumerical() {
		// TODO Auto-generated method stub
		return e.isNumerical();
	}

	
	public override bool isNodeSet() {
		// TODO Auto-generated method stub
		return e.isNodeSet();
	}

	
	public override bool isString() {
		// TODO Auto-generated method stub
		return e.isString();
	}


	public override bool isBoolean() {
		// TODO Auto-generated method stub
		return e.isBoolean();
	}


	public override bool requireContextSize() {
		// TODO Auto-generated method stub
		return e.requireContextSize();
	}

	public override void setContextSize(int size) {
		// TODO Auto-generated method stub
		e.setContextSize(size);
	}

	public override void setPosition(int pos) {
		// TODO Auto-generated method stub
		e.setPosition(pos);
	}

	public override int adjust(int n) {
		// TODO Auto-generated method stub
		return e.adjust(n);
	}

	
	public override bool isFinal() {
		// TODO Auto-generated method stub
		return e.isFinal();
	}

	
	public override void markCacheable() {
		// TODO Auto-generated method stub
		e.markCacheable();
	}


	public override void markCacheable2() {
		// TODO Auto-generated method stub
		e.markCacheable2();
	}
	
	public void clearCache(){
		cached = false;
		if (ens!=null)
			ens.clear();
		e.clearCache();			
	}

}
}
