using System;
using System;
using System.Collections.Generic;
using System.Text;
using com.ximpleware;
namespace tutorial
{
    public class hello_world
    {
        public static void Main(string[] args)
        {
            VTDGen vg = new VTDGen();
            if (vg.parseFile("d:/C#_tutorial_by_code_examples/1/input.xml",true)){
                VTDNav vn = vg.getNav();
		//toElementNS is the namespace aware version of toElement which navigates the cursor
                if (vn.toElementNS(VTDNav.FIRST_CHILD, "someURL", "b")){
                    int i= vn.getText();
		    // convert i into string before printing, 
		    // toNormalizedString(i) and toRawString(i) are two other options
                    if (i!=-1){
                        Console.WriteLine("the text node value at "+i+" ==> "+ vn.toString(i));
                    }
                }
            }
        }
    }
}
