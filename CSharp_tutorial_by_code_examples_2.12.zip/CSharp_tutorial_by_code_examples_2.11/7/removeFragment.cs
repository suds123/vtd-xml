using System;
using System.Collections.Generic;
using System.Text;
using com.ximpleware;
using com.ximpleware.xpath;
namespace tutorial
{
    public class removeFragment
    {
        public static void Main(string[] args)
        {
                int i;
                VTDGen vg = new VTDGen();
                AutoPilot ap = new AutoPilot();
                ap.selectXPath("/root/b");
                XMLModifier xm = new XMLModifier();
                if (vg.parseFile("d:/C#_tutorial_by_code_examples/7/input.xml", true))
                {
                    VTDNav vn = vg.getNav();
                    ap.bind(vn);
                    xm.bind(vn);
                    while ((i = ap.evalXPath()) != -1)
                    {
                        // remove the cursor element in the embedded VTDNav object 
                        xm.remove();
                    }
                    xm.output("d:/C#_tutorial_by_code_examples/7/new.xml");
                }
        }    
    }
}

