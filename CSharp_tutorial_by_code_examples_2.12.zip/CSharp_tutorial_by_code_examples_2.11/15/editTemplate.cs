using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using com.ximpleware;
using com.ximpleware.xpath;

namespace tutorial
{
    public class editTemplate
    {
        public static void Main(string[] args)
        {
            VTDGen vg = new VTDGen();
            FileStream fos = new FileStream("d:/C#_tutorial_by_code_examples/12/new_cd.xml", FileMode.OpenOrCreate);  //("new_cd.xml");
            AutoPilot ap = new AutoPilot();
            ap.selectXPath("/CATALOG/CD");
            if (vg.parseFile("d:/C#_tutorial_by_code_examples/12/cd_Template.xml", false))
            {
                VTDNav vn = vg.getNav();
                ap.bind(vn);
                if (ap.evalXPath() == -1)
                {
                    Console.WriteLine("XPath eval failed");
                    return;
                }
                fillTemplate(vn, "Empire Burlesque", "Bob Dylan", "USA", "Columbia", 10.90, 1985);
                if (ap.evalXPath() == -1)
                {
                    Console.WriteLine("XPath eval failed");
                    return;
                }
                fillTemplate(vn, "Still Got the Blues", "Gary More", "UK", "Virgin Records", 10.20, 1990);
                // dump out the XML
                fos.Write(vn.getXML().getBytes(), 0, vn.getXML().getBytes().Length);
                fos.Close();
            }
        }
        public static void fillTemplate(VTDNav vn,
                String title, String artist, String country,
			String company, double price, int year)
        {
            Encoding eg = System.Text.Encoding.GetEncoding("utf-8");
            int i = -1;
            if (vn.toElement(VTDNav.FIRST_CHILD))
            {
                vn.overWrite(vn.getText(), eg.GetBytes(title));
                vn.toElement(VTDNav.NEXT_SIBLING);
                vn.overWrite(vn.getText(), eg.GetBytes(artist));
                vn.toElement(VTDNav.NEXT_SIBLING);
                vn.overWrite(vn.getText(), eg.GetBytes(country));
                vn.toElement(VTDNav.NEXT_SIBLING);
                vn.overWrite(vn.getText(), eg.GetBytes(company));
                vn.toElement(VTDNav.NEXT_SIBLING);
                vn.overWrite(vn.getText(), eg.GetBytes(price + ""));
                vn.toElement(VTDNav.NEXT_SIBLING);
                vn.overWrite(vn.getText(), eg.GetBytes(year + ""));
            }
            vn.toElement(VTDNav.PARENT);
        }
    }
}

