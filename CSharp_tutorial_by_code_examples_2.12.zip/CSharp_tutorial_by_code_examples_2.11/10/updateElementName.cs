using System;
using System.Collections.Generic;
using System.Text;
using com.ximpleware;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            VTDGen vg = new VTDGen();
            if (vg.parseFile("d:/test.xml", false))
            {
                VTDNav vn = vg.getNav();
                AutoPilot ap = new AutoPilot(vn);
                XMLModifier xm = new XMLModifier(vn);
                ap.selectXPath("//*");
                int i;
                while ((i = ap.evalXPath()) != -1)
                {
                    xm.updateElementName("lalala");
                }
                xm.output("d:/out.xml");
            }
        }
    }
}
