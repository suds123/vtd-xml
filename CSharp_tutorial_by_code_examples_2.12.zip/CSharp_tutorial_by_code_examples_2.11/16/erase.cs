using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using com.ximpleware;
using com.ximpleware.xpath;

namespace tutorial
{
    public class erase
    {
        public static void Main(string[] args)
        {
            VTDGen vg = new VTDGen();
            AutoPilot ap = new AutoPilot();
            ap.selectXPath("/CATALOG/CD[PRICE=10.2]/*/text()");
            if (vg.parseFile("d:/Java_tutorial_by_code_examples/13/old_cd.xml", false))
            {
                VTDNav vn = vg.getNav();
                ap.bind(vn);
                int i;
                Encoding eg = System.Text.Encoding.GetEncoding("utf-8");
                byte[] ba = eg.GetBytes("");
                while ((i = ap.evalXPath()) != -1)
                {
                    vn.overWrite(i, ba);
                }
                FileStream fos = new FileStream("new_cd.xml",FileMode.OpenOrCreate);
                fos.Write(vn.getXML().getBytes(),0,vn.getXML().getBytes().Length);
                fos.Close();
            }
        }
    }
}

