using System;
using System.Collections.Generic;
using System.Text;
using com.ximpleware;
//generate an index file for an input XML
namespace tutorial
{
    public class writeIndex
    {
        public static void Main(string[] args)
        {
            VTDGen vg = new VTDGen();
            if (vg.parseFile("d:/C#_tutorial_by_code_examples/4/input.xml",true)){
                vg.writeIndex("d:/C#_tutorial_by_code_examples/4/input.vxl");
            }
        }
    }
}
