using System;
using System.Collections.Generic;
using System.Text;
using com.ximpleware;
namespace tutorial
{
    public class loadIndex
    {
        public static void Main(string[] args)
        {
            try
            {
                VTDGen vg = new VTDGen();
                VTDNav vn = vg.loadIndex("d:/C#_tutorial_by_code_examples/5/input.vxl");
                // do whatever you want here
            }
            catch (IndexReadException e)
            {
            }
        }
    }
}

