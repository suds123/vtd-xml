/* 
 * Copyright (C) 2002-2004 XimpleWare, info@ximpleware.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.xpath.*;
import javax.xml.transform.stream.*;
import javax.xml.transform.dom.*;
import java.io.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import javax.xml.namespace.NamespaceContext;

public class update_dom3 {
    public static void main(String args[]){
        try{
            int total =60,i1=0,k=0;
			System.setProperty("javax.xml.parsers.SAXParserFactory",
			"org.apache.xerces.jaxp.SAXParserFactoryImpl");
			System.setProperty("javax.xml.parsers.DOMParserFactory",
			"org.apache.xerces.jaxp.DOMParserFactoryImpl");
            // create xpath object
	    String xpe = "/*/*/*[position() mod 2 = 0]";
	    //String xpe = "/purchaseOrder/items/item[USPrice<100]";
	    if (args[0].equals("1")){
		    xpe =  "/purchaseOrder/items/item[USPrice<100]";
	    }else if (args[0].equals("2")){
		    xpe = "/*/*/*/quantity/text()";    
	    } else if (args[0].equals("3")){
		    xpe = "//item/comment";    
	    } else if (args[0].equals("4")){
		    xpe = "//item/comment/../quantity";    
	    }  
	    
            XPathFactory  factory1=XPathFactory.newInstance();
            XPath xPath=factory1.newXPath();
            TransformerFactory tfactory = TransformerFactory.newInstance();
            Transformer tf = tfactory.newTransformer(); 
            // read in file content and create byte array input stream
            File f = new File("po_big.xml");
            byte b[] = new byte[(int)f.length()];
            FileInputStream fis = new FileInputStream(f);
            fis.read(b);
            ByteArrayInputStream bais = new ByteArrayInputStream(b);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            
            DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false );	
            factory.setNamespaceAware(false);
            factory.setExpandEntityReferences(false);
            DocumentBuilder parser = factory.newDocumentBuilder();
            XPathExpression xPathExpression=
                xPath.compile(xpe);
	    System.out.println(" ===> update_dom3 ===>"+xpe);
            
            //parse and xpath eval
            
            Document d = null;
	    k = total;
            while (k > 0) {
		bais.reset();
                d = parser.parse(bais);
                //NodeList nodeList = (NodeList) xPathExpression.evaluate(d,
                //        XPathConstants.NODESET);
                //System.out.println("# of nodes ==>" + nodeList.getLength());

                // remove nodes from DOM tree
                //for (int z = 0; z < nodeList.getLength(); z++) {
                //    nodeList.item(z).getParentNode().removeChild(
                //            nodeList.item(z));
                //}
                baos.reset();
                tf.transform(new DOMSource(d), new StreamResult(baos));
		k--;
            }
            long l=0,lt=0;
    	    for (int j = 0; j < 10; j++) {
                l = System.currentTimeMillis();
                for (int i = 0; i < total; i++) {
		    bais.reset();
                    d = parser.parse(bais);
                    //NodeList nodeList = (NodeList) xPathExpression.evaluate(d,
                    //        XPathConstants.NODESET);
                    //System.out.println("# of nodes ==>" + nodeList.getLength());

                    // remove nodes from DOM tree
                    //for (int z = 0; z < nodeList.getLength(); z++) {
                    //    nodeList.item(z).getParentNode().removeChild(
                    //            nodeList.item(z));
                    //}
                    baos.reset();
                    tf.transform(new DOMSource(d), new StreamResult(baos));
                }
                long l2 = System.currentTimeMillis();
                lt = lt + (l2 - l);
            }
            System.out.println(" average combined latency ==> "
                    + ((double) (lt) / total / 10) + " ms");
    	    	
            
            
            //System.out.println(baos.toString());
            // transform into byteArray output stream
            
        }catch(XPathExpressionException e){
            
        }catch(IOException e){
            
        }catch (Exception e){
            
        }
    }
}

