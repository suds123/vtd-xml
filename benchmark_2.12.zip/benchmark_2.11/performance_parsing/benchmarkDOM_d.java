import com.ximpleware.*;
import com.ximpleware.parser.*;
import java.io.*;
import org.w3c.dom.*;
import org.w3c.*;
import javax.xml.parsers.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class benchmarkDOM_d {
      public static void main(String[] args){
	
	File f = new File(args[0]);
	try{
	    FileInputStream fis = new FileInputStream(f);
	    byte[] ba = new byte[(int)f.length()];
	    fis.read(ba); 	    
	    //vg.setDoc(ba);
	    DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
	    factory.setNamespaceAware(true);
	    factory.setExpandEntityReferences(false);
	    DocumentBuilder parser = factory.newDocumentBuilder();
	    int total;
	    int fl = (int) f.length();
	    if (fl <6000)
		    total = 2000;
	    else if (fl <15000)
		    total = 800;
	    else if (fl<30000)
		    total = 250;
	    else if (fl < 60000)
		    total = 200;
	    else if (fl < 120000)
		    total = 100;
	    else if (fl <500000)
		    total = 30;
	    else if (fl < 2000000)
		    total = 10;
	    else 
		    total = 5;
	    long l,lt=0;
	    l = System.currentTimeMillis();
	    ByteArrayInputStream bais = new ByteArrayInputStream(ba);
	    while(System.currentTimeMillis()-l<30000)
	    {
	       bais.reset();
	       parser.parse(bais); 
	    }
	    for(int j=0;j<10;j++) {
	    l = System.currentTimeMillis();
	    	for(int i = 0;i<total;i++)
	    	{
	           bais.reset();
	       	   parser.parse(bais);  
	        }
	       	long l2 = System.currentTimeMillis();
                lt = lt+ (l2-l);
	    }
       	    System.out.println(" average parsing time ==> "+ 
			    ((float)(lt)/total/10));
	    System.out.println(" performance ==> "+ 
	    		    (((double)fl *1000 * total)/((lt/10)*(1<<20))));
	}
	catch (Exception e){
		System.out.println("exception ==> "+e);
	} 
      }
}
