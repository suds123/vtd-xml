import java.io.*;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class benchmarkPull {
  public static void main(String argv[])
  {
	  long a;
       try {
        //    XmlPullParserFactory factory = XmlPullParserFactory.newInstance(
        //       System.getProperty(XmlPullParserFactory.PROPERTY_NAME), null);
        //    factory.setNamespaceAware(true);
        //    XmlPullParser xpp = factory.newPullParser();
       //System.setProperty("org.xmlpull.v1.XmlPullParserFactory","org.xmlpull.v1.XmlPullParserFactory");
       //XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
	XmlPullParserFactory factory = XmlPullParserFactory.newInstance(
           System.getProperty(XmlPullParserFactory.PROPERTY_NAME), null);
       
	// Thread.currentThread().getContextClassLoader().getClass() );
       
 	//System.out.println("hi----->"+factory.getClass());
	//System.out.println("hi----->");
	//	"org.xmlpull.v1.XmlPullParserFactory", 
	//	Thread.getContextReader);
       
                   //System.getProperty(XmlPullParserFactory.PROPERTY_NAME), null);
        //factory.setNamespaceAware(true);
        factory.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);

	//System.out.println("hi----->");
        XmlPullParser xpp = factory.newPullParser();
        //System.out.println("parser implementation class is "+xpp.getClass());
 
	    
            File f= new File(argv[0]);
            FileInputStream fi = null;
            byte[] bt;
            fi = new FileInputStream(f);
            System.out.println(" file size "+(int)f.length());
            bt = new byte[(int)f.length()];
            fi.read(bt);       
            
             int total;
	     int fl = (int) f.length();
	     if (fl <6000)
		    total = 2000;
	    else if (fl <15000)
		    total = 800;
	    if (fl<30000)
		    total = 500;
	    else if (fl < 60000)
		    total = 300;
	    else if (fl < 120000)
		    total = 150;
	    else if (fl <500000)
		    total = 50;
	    else if (fl < 2000000)
		    total = 20;
	    else 
		    total = 5;;
            a = System.currentTimeMillis();
            ByteArrayInputStream bais  = new ByteArrayInputStream(bt);
            while(System.currentTimeMillis()-a <30000)
            {
		bais.reset();
		xpp.setInput(bais,null);
		int eventType = xpp.getEventType();
		do {
		   eventType = xpp.nextToken();
		}while (eventType != XmlPullParser.END_DOCUMENT);
                //saxParser.parse( new File(argv[0]), handler );
            }
        
	    long lt = 0;
            // Parse the input
            //saxParser = factory.newSAXParser();
	    for (int j = 0;j<10;j++){
            	a = System.currentTimeMillis();
            	for(int i=0;i<total;i++)
            	{
 		    bais.reset();
		    xpp.setInput(bais,null);
		    int eventType = xpp.getEventType();
		    do {
		       eventType = xpp.nextToken();
		    }while (eventType != XmlPullParser.END_DOCUMENT);
                //saxParser.parse( new File(argv[0]), handler );
            	}       
          	long l2 = System.currentTimeMillis();
		lt = lt + (l2 - a);
	    }
    	    System.out.println(" average parsing time ==> "+ 
		    ((float)(lt)/total/10));
	    System.out.println(" performance ==> "+ 
	   	    ( ((double)fl *1000 * total)/((lt/10)*(1<<20))));
        } catch (Exception e)
    {
           System.out.println( e);
    }
    catch (Throwable t) {
            t.printStackTrace();
    }
  }
}

