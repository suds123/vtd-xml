import com.ximpleware.*;
import com.ximpleware.parser.*;
import java.io.*;


public class benchmark {
      public static void main(String[] args){
	
	File f = new File(args[0]);
	//File f1 = new File("c:\\soap.xml");
	long l,lt = 0;
	try{
	    FileInputStream fis = new FileInputStream(f);
	    byte[] ba = new byte[(int)f.length()];
	    //FileInputStream fis1 = new FileInputStream(f1);
	    //byte[] ba1 = new byte[(int)f1.length()];
	    fis.read(ba);
	    //fis1.read(ba1);
	    VTDGen vg = new VTDGen();
	    //vg.setDoc(ba);
	    int fl = (int) f.length();
	    System.out.println("fl is "+fl);
	    System.out.println(" 10>>11 "+  (10>>11));
	    int total;
	    if (fl <1000)
		    total =40000;
	    else if (fl< 3000)
		    total =20000;
	    else if (fl <6000)
		    total = 4000;
	    else if (fl <15000)
		    total = 1600;
	    else if (fl<30000)
		    total = 1000;
	    else if (fl < 60000)
		    total = 600;
	    else if (fl < 120000)
		    total = 300;
	    else if (fl <500000)
		    total = 100;
	    else if (fl < 2000000)
		    total = 40;
	    else 
		    total = 5;
	    System.out.println("total is "+total);

	    l = System.currentTimeMillis();
            while(System.currentTimeMillis()-l<30000)      
	    {
	       vg.setDoc(ba);
	       vg.parse(true); 
	    }
	    for (int j=0;j<10;j++){
	    	l = System.currentTimeMillis();
	    	for(int i = 0;i<total;i++)
	    	{
			vg.setDoc(ba);
	       		vg.parse(true); 
	    	}
		long l2 = System.currentTimeMillis();
		lt = lt + (l2 - l);
	    }
   	    //System.out.println("latency "+ ((double)lt/10)+ " ms");
	    System.out.println(" average parsing time ==> "+ 
		        ((double)(lt)/total/10) + " ms");
	    System.out.println(" performance ==> "+ 
			( ((double)fl *1000 * total)/((lt/10)*(1<<20))));
	}
	catch (ParseException e){	
		System.out.println(" Not wellformed -->" +e);
	}
	catch (IOException e){
		System.out.println(" io exception ");
	} 
      }
}
