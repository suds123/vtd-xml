import com.ximpleware.*;
import com.ximpleware.parser.*;
import java.io.*;
import org.w3c.dom.*;
import org.w3c.*;
import javax.xml.parsers.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class benchmarkDOM_mem_d {
	static Runtime rt;
      public static void main(String[] args){
	
	File f = new File(args[0]);
	try{
	    FileInputStream fis = new FileInputStream(f);
            rt = Runtime.getRuntime();
	    byte[] ba = new byte[(int)f.length()];
	    fis.read(ba); 
	    //vg.setDoc(ba);
	    long startMem = rt.totalMemory() - rt.freeMemory();
	    DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
	    factory.setNamespaceAware(true);
	    factory.setExpandEntityReferences(false);
	 
	    DocumentBuilder parser = factory.newDocumentBuilder();
	    ByteArrayInputStream bais = new ByteArrayInputStream(ba);
	    parser.parse(bais);
            long endMem = rt.totalMemory() - rt.freeMemory();
            System.out.println("Memory Use: " + ((float) endMem - startMem)/(1<<20) + " MB.");
	    System.out.println("Multiplying factor: " + ((float) endMem - startMem)/f.length() );
	}
	catch (Exception e){
		System.out.println("exception ==> "+e);
	} 
      }
}
