
/* 
 * Copyright (C) 2002-2004 XimpleWare, info@ximpleware.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
import com.ximpleware.*;
import com.ximpleware.xpath.*;
import java.io.*;

public class roundTrip_vtd {
    public static void main(String args[]){
        try{
            int i1=0,k=0, total=6000;
	    long l=0,lt=0;

            File f = new File(args[0]);
	    int fl = (int) f.length();
            byte b[] = new byte[(int)f.length()];
	     if (fl <1000)
		    total =40000;
	    else if (fl< 3000)
		    total =20000;
	    else if (fl <10000)
		    total = 4000;
	    else if (fl <15000)
		    total = 4000;
	    else if (fl<30000)
		    total = 2000;
	    else if (fl < 60000)
		    total = 1200;
	    else if (fl < 120000)
		    total = 600;
	    else if (fl <500000)
		    total = 200;
	    else if (fl < 2000000)
		    total = 80;
	    else 
		    total = 10;
	    System.out.println("total is "+total); 
            FileInputStream fis = new FileInputStream(f);
            fis.read(b);
            VTDGen vg = new VTDGen();
            XMLModifier xm = new XMLModifier();            
            ByteArrayOutputStream baos = new ByteArrayOutputStream();            
            //ap.selectXPath("/purchaseOrder/items/item");
            k=total;
	    VTDNav vn = null;
	    while(k>0){
	    	vg.setDoc(b);
	    	vg.parse(true);
          	vn = vg.getNav();
            	xm.bind(vn);
            	xm.output(baos);
            	xm.reset();
	    	baos.reset();
	    	k--;
	    }
	    for (int j=0;j<10;j++){
	    	l = System.currentTimeMillis();
	    	for(int i = 0;i<total;i++)
	    	{
		    vg.setDoc(b);
           	    vg.parse(true);
		    //vn = vg.getNav();
	    	    //xm.bind(vn);
	            //xm.output(baos);
		    //xm.reset();
		    //baos.reset();
	    	}
		long l2 = System.currentTimeMillis();
		lt = lt + (l2 - l);
		//System.out.println("j ==> "+j);
	    }
	    System.out.println(" average parsing latency ==> "+ 
		        ((double)(lt)/total/10) + " ms");
            //System.out.println(baos.toString());
	    lt = 0;
	    for (int j=0;j<10;j++){
	    	l = System.currentTimeMillis();
	    	for(int i = 0;i<total;i++)
	    	{
		    vg.setDoc(b);
           	    vg.parse(true);
		    vn = vg.getNav();
	    	    xm.bind(vn);
	            xm.output(baos);
		    xm.reset();
		    baos.reset();
	    	}
		long l2 = System.currentTimeMillis();
		lt = lt + (l2 - l);
		//System.out.println("j ==> "+j);
	    }
	    System.out.println(" average combined latency ==> "+ 
		        ((double)(lt)/total/10) + " ms");
            //System.out.println(baos.toString());
            
        }catch(IOException e){
		System.out.println(" error ==> "+e);
        }catch(Exception e){
		System.out.println(" error ==> "+e);
        }
    }
}
