import javax.xml.parsers.*;
//import javax.xml.transform.*;
//import javax.xml.xpath.*;
//import javax.xml.transform.stream.*;
//import javax.xml.transform.dom.*;
import java.io.*;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
//import javax.xml.namespace.NamespaceContext;
import org.jaxen.*;
import org.jaxen.dom.*;
import java.util.*;
public class xpath_jaxen2 {
    public static void main(String args[]){
        try{
            int total =2000,i1=0,k=0;
			System.setProperty("javax.xml.parsers.SAXParserFactory",
			"org.apache.xerces.jaxp.SAXParserFactoryImpl");
			System.setProperty("javax.xml.parsers.DOMParserFactory",
			"org.apache.xerces.jaxp.DOMParserFactoryImpl");
            // create xpath object
	    String xpe = xp.getXPath(args[0]); 
	    
            //XPathFactory  factory1=XPathFactory.newInstance();
            //XPath xPath=factory1.newXPath();
            //TransformerFactory tfactory = TransformerFactory.newInstance();
            //Transformer tf = tfactory.newTransformer(); 
            // read in file content and create byte array input stream
            File f = new File("po_medium.xml");
            byte b[] = new byte[(int)f.length()];
            FileInputStream fis = new FileInputStream(f);
            fis.read(b);
            ByteArrayInputStream bais = new ByteArrayInputStream(b);
            
            DocumentBuilderFactory factory =
				DocumentBuilderFactory.newInstance();
            factory.setFeature("http://apache.org/xml/features/dom/defer-node-expansion", false );	
            factory.setNamespaceAware(false);
            factory.setExpandEntityReferences(false);
            DocumentBuilder parser = factory.newDocumentBuilder();
            XPath expression = new org.jaxen.dom.DOMXPath(xpe);
            //Navigator navigator = expression.getNavigator();

              
	    
            //XPathExpression xPathExpression=
            //    xPath.compile(xpe);
            System.out.println("====> update_jaxen1 ==>"+xpe); 
            //parse and xpath eval
            
            Document d = null;
                d = parser.parse(bais);
	    k = total;
            while (k > 0) {
                List results = expression.selectNodes(d);
		//int i = nodeList.getLength();
                //System.out.println("# of nodes ==>" + nodeList.getLength());

                // remove nodes from DOM tree
                /*for (int z = 0; z < nodeList.getLength(); z++) {
                    nodeList.item(z).getParentNode().removeChild(
                            nodeList.item(z));
                }
                baos.reset();
                tf.transform(new DOMSource(d), new StreamResult(baos));*/
		k--;
            }
            long l=0,lt=0;
    	    for (int j = 0; j < 10; j++) {
                l = System.currentTimeMillis();
                for (int i = 0; i < total; i++) {
   		    List results = expression.selectNodes(d);
                    //System.out.println("# of nodes ==>" + nodeList.getLength());

                    /* remove nodes from DOM tree
                    for (int z = 0; z < nodeList.getLength(); z++) {
                        nodeList.item(z).getParentNode().removeChild(
                                nodeList.item(z));
                    }
                    baos.reset();*/
                }
                long l2 = System.currentTimeMillis();
                lt = lt + (l2 - l);
            }
            System.out.println(" average XPath latency ==> "
                    + ((double) (lt) / total / 10) + " ms");
    	    	
            
            
            //System.out.println(baos.toString());
            // transform into byteArray output stream
            
        }catch(IOException e){
            
        }catch (Exception e){
            
        }
    }
}

