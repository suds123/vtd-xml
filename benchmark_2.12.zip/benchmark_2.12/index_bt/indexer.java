import com.ximpleware.*;

// read in an XML file
// 
public class indexer{
	public static void main(String s[]) throws Exception{
		System.out.println("s0 ==> "+s[0]);
		System.out.println("s1 ==> "+s[1]);
		VTDGen vg=new VTDGen();
		if (vg.parseFile(s[0],true)){
			vg.writeIndex(s[1]);
			
		}
	}
}
